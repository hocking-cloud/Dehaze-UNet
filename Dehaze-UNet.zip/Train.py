import sys
import argparse
import torch.nn.functional as  F
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
from torch.utils.data import DataLoader
from torch.autograd import Variable
from torchvision.utils import save_image
from visdom import Visdom


from loss import SSIM
from data import *
from res_net import *
inputPathTrain_j = '/data/Dehazing/OTS_ALPHA/haze/OTS' # 输入的训练文件j
targetPathTrain = '/data/Dehazing/OTS_ALPHA/clear/clear_images' # 输入训练集的无雾图像

inputPathTest = '/data/Dehazing/czk_SOTS/indoor/hazy'
targePathtest = '/data/Dehazing/czk_SOTS/indoor/gt'
# imagename = os.listdir(inputPathTest)

parser = argparse.ArgumentParser()
parser.add_argument("--EPOCH", type=int, default=1, help="starting epoch")
parser.add_argument("--BATCH_SIZE", type=int, default=128, help="size of the batches")
parser.add_argument("--PATCH_SIZE", type=int, default=256, help="size of the patch")
parser.add_argument("--LEARNING_RATE", type=float, default=2e-3, help="initial learning rate")
opt = parser.parse_args()

criterion1 = SSIM().cuda()
criterion2 = nn.L1Loss().cuda()
# 实例化数据加载器及模型
swinIR2 = Generator()
swinIR2.cuda()
device_ids = [i for i in range(torch.cuda.device_count())]
if len(device_ids) > 1:
    swinIR2 = nn.DataParallel(swinIR2, device_ids=device_ids)
optimizer = torch.optim.AdamW([
            {'params': swinIR2.parameters(),"lr" : opt.LEARNING_RATE,"betas" : [0.9,0.99]},
        ])
cosinese =  torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=100,eta_min=2e-5)
datasetTrain = MyTrainDataSet(inputPathTrain_j, targetPathTrain, patch_size=opt.PATCH_SIZE)
trainLoader = DataLoader(dataset=datasetTrain, batch_size=opt.BATCH_SIZE, shuffle=True, num_workers=20,drop_last=True,
                         pin_memory=True)
datasetTest = MyValueDataSet(inputPathTest, targePathtest)
valueLoader = DataLoader(dataset=datasetTest, batch_size=1, shuffle=False, drop_last=True, num_workers=20,
                         pin_memory=True)

# # 实例化窗口
# wind = Visdom()
# 初始化窗口信息
# wind.line([0.],[0.], win = 'l1', opts = dict(title = 'l1'))
# wind.line([0.],[0.], win = 'ssim', opts = dict(title = 'ssim'))

best_psnr = 0

#网络参数数量
output_images = '/home/ubuntu/Desktop/shujuji/noskip/'
print('-------------------------------------------------------------------------------------------------------')
# # loss_list = []
swinIR2.load_state_dict(torch.load('./notskip.pth'))
# print(1111)
for epoch in range(opt.EPOCH):
    swinIR2.train(True)
    # 进度条
    iters = tqdm(trainLoader, file=sys.stdout)
    epochLoss1 = 0
    epochLoss2 = 0
    tureloss = 0
    # for index, (j, ture_j) in enumerate(iters, 0):
    #     swinIR2.zero_grad()
    #     optimizer.zero_grad()
    #     # 包装Tensor，将Tensor转换为Variable之后，可以装载梯度信息
    #     j_, ture_j_ = Variable(j).cuda(), Variable(ture_j).cuda()
    #     j2 = swinIR2(j_)
    #     loss1 = criterion1(j2, ture_j_)
    #     loss2 = criterion2(j2, ture_j_)
    #
    #     loss =  loss2+(1-loss1)
    #     loss.backward()
    #     optimizer.step()
    #     # 进度条
    #     epochLoss1 +=loss1.item()
    #     epochLoss2 +=loss2.item()
    #
    #     iters.set_description('Training !!!  Epoch %d / %d,  Batch Loss1 %.6f,batch Loss2 %.6f' % (epoch + 1, opt.EPOCH, loss1.item(),loss2.item()))
    # cosinese.step()
    print(epochLoss1,epochLoss2)
    # wind.line([epochLoss1], [epoch], win='ssim', update='append')
    # wind.line([epochLoss2], [epoch], win='l1', update='append')
    psnr_val_rgb = []
    psnr_val_rgb2 = []
    # i = 0
    if epoch>=0:
        swinIR2.eval()
        for index, (test_j, test_ture_j) in enumerate(valueLoader, 0):
            test_j_,test_ture_j_ = test_j.cuda(), test_ture_j.cuda()
            with torch.no_grad():
                test_fake_j = swinIR2(test_j_)
            ps = 20*torch.log10((1./criterion2(test_fake_j,test_ture_j_)))
            ssim = criterion1(test_fake_j,test_ture_j_)
            save_image(test_fake_j, output_images + str(index)+str("|") + str(ssim.item())+str("|")+ str(ps.item())+str(".png"))
            psnr_val_rgb2.append(ssim)
            psnr_val_rgb.append(ps)
        psnr_val_rgb = torch.stack(psnr_val_rgb).mean().item()
        psnr_val_rgb2 = torch.stack(psnr_val_rgb2).mean().item()
        # if psnr_val_rgb>best_psnr:
        #     best_psnr=psnr_val_rgb
        #     torch.save(swinIR2.state_dict(), './instancnormoutdoor.pth')
        print(psnr_val_rgb,psnr_val_rgb2)

