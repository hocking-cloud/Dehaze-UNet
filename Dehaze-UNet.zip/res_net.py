import math
import random

import  natsort
import torch

import torch.nn as nn
import torch.nn.functional as F
import torch.utils.checkpoint as checkpoint

class Layer(nn.Module):
    def __init__(self, in_features):
        super(Layer, self).__init__()
        self.norm = nn.BatchNorm2d(in_features)
        self.conv_block1 = nn.Sequential(
            nn.Conv2d(in_features, in_features,3,1,1,padding_mode="reflect"),
            nn.BatchNorm2d(in_features),
            nn.ReLU(True),
            nn.Conv2d(in_features, in_features, 3,1,1,padding_mode="reflect"),
            nn.ReLU(True),
            nn.BatchNorm2d(in_features),
        )
        self.conv_block2 = nn.Sequential(
            nn.Conv2d(in_features, in_features,3,1,1,padding_mode="reflect"),
            nn.BatchNorm2d(in_features),
            nn.ReLU(True),
            nn.Conv2d(in_features, in_features, 3,1,1,padding_mode="reflect"),
            nn.ReLU(True),
            nn.BatchNorm2d(in_features),
        )

        self.conv = nn.Conv2d(in_features, in_features,1,groups=in_features)
    def forward(self, x):
        x = self.norm(x)
        mid = self.conv_block1(x)*self.conv_block2(x)
        out = self.conv(mid)
        return x+out
class Down(nn.Module):
    def __init__(self, in_features,out_features):
        super(Down, self).__init__()

        self.down = nn.Sequential(
            nn.Conv2d(in_features, out_features, 2, stride=2),
        )
    def forward(self, x):
        out = self.down(x)
        return out
class Up(nn.Module):
    def __init__(self, in_features,out_features):
        super(Up, self).__init__()

        self.up = nn.Sequential(
            nn.Conv2d(in_features, out_features * 4, 1),
            nn.PixelShuffle(2),
        )
    def forward(self, x):
        out = self.up(x)
        return out
class ASFuction(nn.Module):
    def __init__(self, in_features):
        super(ASFuction, self).__init__()

        self.shallow = nn.Sequential(
            nn.BatchNorm2d(in_features),
            nn.ReLU(True),
        )
        self.MLP_A = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_features,in_features*2,1,bias=False),

            nn.Conv2d(in_features*2, in_features , 1,bias=False),
        )
        self.MLP_T = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_features,2*in_features,1,bias=False),

            nn.Conv2d(2*in_features,in_features, 1,bias=False),
        )
    def forward(self, x):
        mid = self.shallow(x)

        t = self.MLP_T(mid)
        b,c,h,w = t.shape
        a = self.MLP_A(mid)
        one = torch.ones((b,c,h,w)).cuda()
        return(x+a*(t-one))*t
class Generator(nn.Module):
    def __init__(self, input_nc=3, output_nc=3):
        super(Generator, self).__init__()
        in_features = 96
        self.inconv = nn.Conv2d(3, in_features,1)

        self.down1 = Down(in_features,in_features*2)
        self.skip1 = nn.Conv2d(in_features*2,in_features*2,1)
        # self.layer1_1 = Layer(in_features*2)
        # self.layer1 = Layer(in_features * 2)


        self.down2 = Down(in_features*2,in_features*4)
        self.skip2 = nn.Conv2d(in_features*4,in_features*4,1)
        # self.layer2 = Layer(in_features*4)
        # self.layer2_2 = Layer(in_features * 4)


        self.layer_mid   = Layer(in_features * 4)
        self.layer_mid_2 = Layer(in_features * 4)
        self.layer_mid_3 = Layer(in_features * 4)
        self.layer_mid_4 = Layer(in_features * 4)
        self.layer_mid_5 = Layer(in_features * 4)
        self.layer_mid_6 = Layer(in_features * 4)
        self.layer_mid_7 = Layer(in_features * 4)
        self.layer_mid_8 = Layer(in_features * 4)



        self.asuction1 = ASFuction(in_features*4)
        self.up1 = Up(in_features * 4, in_features * 2)


        self.asuction2 = ASFuction(in_features*2)
        self.up2 = Up(in_features * 2, in_features)

        self.outconv = nn.Conv2d(in_features,output_nc,1)
        # self.relu = nn.ReLU(True)
    def forward(self, x):
        skpi = []
        out = self.inconv(x)

        out = self.down1(out)
        skpi.append((out))


        out = self.down2(out)
        skpi.append((out))


        out = self.layer_mid(out)
        out = self.layer_mid_2(out)
        out = self.layer_mid_3(out)
        out = self.layer_mid_4(out)
        out = self.layer_mid_5(out)
        out = self.layer_mid_6(out)
        out = self.layer_mid_7(out)
        out = self.layer_mid_8(out)



        out = self.asuction1(out)+skpi[-1]
        out = self.up1(out)


        out = self.asuction2(out)+skpi[-2]
        out = self.up2(out)

        out = self.outconv(out)
        return x+out

