import os
import random
import time
import torchvision
import torch
import torchvision.transforms.functional as ttf
from torch.utils.data import Dataset
from PIL import Image
import natsort
from torchvision.utils import save_image
from torchvision.transforms import Resize
class MyValueDataSet(Dataset):
    def __init__(self, inputPathTest_j,targetPathTest):
        super(MyValueDataSet, self).__init__()
        #文件路径
        self.inputPath_j = inputPathTest_j
        #获取文件路径的所有文件
        """
        这里的natsort可以保证他是按名字顺序读取，没什么特殊的
        """
        self.inputImages_j = natsort.natsorted(os.listdir(inputPathTest_j), alg=natsort.ns.PATH)
        #同上
        self.targetPath = targetPathTest
        self.targetImages = natsort.natsorted(os.listdir(targetPathTest), alg=natsort.ns.PATH)
    def __len__(self):
        return len(self.inputImages_j)
        """
        记住记住，这里唯一的重点就是你数据的长度是用len函数判定的，我们一般选择配对数据集中较短的那个，然后index取下标
        index1可以取另一个
        
        """
    def __getitem__(self, index):
        #以rgb形式读取图片
        """
        有的时候图片并不是11对应的，有可能是1：10这种，我们已经用natsort排好序了，此时
        你只需要引入一个index1 像下面那个，之后使用的话，把index换成，index1就好了
        """
        index1 = index//10
        """
        这里简述一下就是说你读取了一张图片的路径然后用image.open去打开
        """
        inputImagePath_j = os.path.join(self.inputPath_j, self.inputImages_j[index])
        inputImage_j = Image.open(inputImagePath_j).convert('RGB')

        targetImagePath = os.path.join(self.targetPath, self.targetImages[index1])
        targetImage = Image.open(targetImagePath).convert('RGB')
        #把他们转换成torch所需的数据类型
        inputImage_j = ttf.to_tensor(inputImage_j)
        targetImage = ttf.to_tensor(targetImage)
        # inputImage_j = self.resize(inputImage_j)
        # targetImage = self.resize(targetImage)
        return inputImage_j, targetImage
"""
这里的类基本和上述一样
一样的我就不多说了
"""
class MyTrainDataSet(Dataset):
    def __init__(self, inputPathTrain_j, targetPathTrain,patch_size=96):
        super(MyTrainDataSet, self).__init__()
        #文件路径
        self.inputPath_j = inputPathTrain_j
        #获取文件路径的所有文件
        self.inputImages_j = natsort.natsorted(os.listdir(inputPathTrain_j), alg=natsort.ns.PATH)
        #同上
        self.targetPath = targetPathTrain

        self.targetImages = natsort.natsorted(os.listdir(targetPathTrain), alg=natsort.ns.PATH)
        #图片尺寸
        self.ps = patch_size
        self.resize = Resize([512,512])
    #获取文件数量
    def __len__(self):
        return len(self.inputImages_j)
    #当对象是序列时，键是整数。当对象是映射时（字典），键是任意值。
    def __getitem__(self, index):
        #以rgb形式读取图片
        ps = self.ps
        index1 = index//35
        inputImagePath_j = os.path.join(self.inputPath_j, self.inputImages_j[index])
        inputImage_j = Image.open(inputImagePath_j).convert('RGB')
        targetImagePath = os.path.join(self.targetPath, self.targetImages[index1])
        targetImage = Image.open(targetImagePath).convert('RGB')
        #转换成张量
        inputImage_j = ttf.to_tensor(inputImage_j)
        targetImage = ttf.to_tensor(targetImage)
        inputImage_j = self.resize(inputImage_j)
        targetImage = self.resize(targetImage)
        #获取长宽
        hh, ww = targetImage.shape[1], targetImage.shape[2]
        #然后随机生成两个坐标
        rr = random.randint(0, hh-ps)
        cc = random.randint(0, ww-ps)
        #批量获取张量
        #用这个坐标然后我们前面的ps就是图片尺寸 patchsize给图片截一块下来训练（主要是这样训练省内存）
        input_j = inputImage_j[:, rr:rr+ps, cc:cc+ps]
        target = targetImage[:, rr:rr+ps, cc:cc+ps]
        return input_j , target
